import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;



public class CreateSequentialFile extends TecladoVirtual {
	private ObjectOutputStream output; 
	public void openFile() {
		try // open file
		{
			output = new ObjectOutputStream(new FileOutputStream( "serial.txt" ) );
		} // end try
		catch ( IOException ioException )
		{
			System.err.println( "Error opening file." );
		} // end catch
	} // end method openFile

	// add records to file
	public void addRecords(String frase)
	{ 
		BufferedWriter bw = null;
		try {
			File file = new File("serial.txt");
			if (!file.exists()) {
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file);
			bw = new BufferedWriter(fw);
			bw.write(frase);

		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		finally
		{ 
			try{
				if(bw!=null)
					bw.close();
			}catch(Exception ex){
				System.out.println("Error in closing the BufferedWriter"+ex);
			}
		}
	}

	public void closeFile() 
	{
		try // close file
		{
			if ( output != null )
				output.close();
		} // end try
		catch ( IOException ioException )
		{
			System.err.println( "Error closing file." );
			System.exit( 1 );
		} // end catch
	} // end method closeFile
} // end class CreateSequentialFile

