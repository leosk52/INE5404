import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class TecladoVirtual extends JFrame {

	int contador=0, acertos=0;//monitorar
	boolean pressionou = false; //p/excecao
	private JLabel labelTec; 
	JTextArea textArea;
	private JButton[] buttons;	
	private static final String[] lista = { "~", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "+", "Backspace",
			"Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\",
			"Caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ":", "*", "Enter", "",
			"Shift", "", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "?", "^", "", 
			"", "", "", "", "", "", "", "", "", "", " " + " " +" " +" ", "<", "v", ">"};

	private static final String[] lista2 = { "Til", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Menos", "Igual", "Backspace",
			"Guia", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "Par�ntese de Abertura", "Par�ntese de Fechamento", "Barra Invertida",
			"Caps Lock", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Ponto-e-V�rgula", "Shift8", "Enter", "",
			"Shift", "", "Z", "X", "C", "V", "B", "N", "M", "V�rgula", "Ponto Final", "Desconhecido keyCode: 0x0", "Acima", "", 
			"", "", "", "", "", "", "", "", "", "", "Espa�o", "Esquerda", "Abaixo", "Direita"};

	//p/ contador funcionar
	private static final String[] especiais = {"Igual", "Backspace", "Guia", "Caps Lock", "Ponto-e-V�rgula", "Shift8", "Shift", "Enter",
			"Desconhecido keyCode: 0x0", "Acima", "Esquerda", "Abaixo", "Direita"};

	String[] frases =  {"Um pequeno jabuti xereta viu dez cegonhas felizes                        ",
			"Jane quer LP, fax, CD, giz, TV e bom whisky                     ",
			"Blitz prende ex-vesgo com cheque fajuto                          "
	};

	Random r = new Random();
	int teste;	


	public TecladoVirtual() {
		super("Teclado Virtual");

		teste = r.nextInt(3);

		buttons = new JButton[lista.length];
		JButton[][] matrizBotoes;


		for (int i = 0; i < lista.length; i++) {
			buttons[i] = new JButton(lista[i]);
			buttons[i].setMinimumSize(new Dimension(90, 50));
			buttons[i].setPreferredSize(new Dimension(90, 50));
			buttons[i].setMaximumSize(new Dimension(90, 50));

		}
		JPanel jPanelMatrizBotoes;

		matrizBotoes = new JButton[5][14];

		setLayout(new FlowLayout(FlowLayout.LEADING));

		jPanelMatrizBotoes = new JPanel(new GridLayout(matrizBotoes.length, matrizBotoes[0].length, 1, 1));
		jPanelMatrizBotoes.setBorder(new EmptyBorder(1, 1, 1, 1));

		int count = 0;
		int nLinhas = matrizBotoes.length;
		int nColunas = matrizBotoes[0].length;
		for (int i = 0; i < nLinhas; i++) {
			for (int j = 0; j < nColunas; j++) {

				matrizBotoes[i][j] = buttons[count];
				jPanelMatrizBotoes.add(matrizBotoes[i][j]);
				if(lista[count] == "") {
					buttons[count].setVisible(false);
				}
				count++;
			}
		}

		add(jPanelMatrizBotoes);

		//////////////////////////////

		labelTec = new JLabel("Frase aleat�ria: " + frases[teste]);
		textArea = new JTextArea(20, 40);		
		Box box = Box.createHorizontalBox();
		box.add(new JScrollPane(textArea));
		add(box);
		box.setVisible(true);

		add(box);
		add(textArea);
		add(labelTec);

		OuvidorBotao ouvBotao = new OuvidorBotao();
		textArea.addKeyListener(ouvBotao);
		addKeyListener(ouvBotao);

		
	}

	private class OuvidorBotao implements KeyListener {


		@Override
		public void keyPressed(KeyEvent e) throws RuntimeException {
			CreateSequentialFile application = new CreateSequentialFile();

			if(e.getKeyChar() == frases[teste].charAt(contador)) {
				acertos++;
			}

			try {
				if(KeyEvent.getKeyText(e.getKeyCode()) == lista2[40]) {
					pressionou = true;	
					JOptionPane.showMessageDialog(null, "Voce apertou " + contador + " teclas, acertou " + acertos
							+ " e errou " + (contador-acertos) );
					application.addRecords(textArea.getText());
					acertos = 0;
					contador = 0;					
				}

				if (e.getKeyChar() == lista[39].charAt(0)) {
					buttons[39].setBackground(Color.MAGENTA);
					pressionou = true;
				}

				for(int i=0; i < lista2.length; i++) {
					if( lista2[i].equalsIgnoreCase( KeyEvent.getKeyText(e.getKeyCode() ) )) {
						buttons[i].setBackground(Color.MAGENTA);
						pressionou = true;
						if(lista2[i].equalsIgnoreCase(lista2[13])) {
							contador--;
							acertos--;
						}
					} 
				}
				int soma = 0;
				for(int i=0; i < especiais.length; i++) {
					if (!especiais[i].equalsIgnoreCase(KeyEvent.getKeyText(e.getKeyCode() ))) {
						soma++;
					}
				}
				if(soma == 13) {
					contador++;
				}

				
				
				if(pressionou == false) {
					throw new RuntimeException();
				}
				pressionou = false;

			} catch (RuntimeException f) {
				JOptionPane.showMessageDialog(null, "Tecla inexistente");
			}{

			}
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			for(int i = 0; i < lista.length; i++) {
				buttons[i].setBackground(null);
			}

		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}
	}
	



}