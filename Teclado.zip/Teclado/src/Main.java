
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {

		TecladoVirtual teclado = new TecladoVirtual();
		teclado.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		teclado.setSize(1300, 800);
		teclado.setVisible(true);
		
		CreateSequentialFile application = new CreateSequentialFile();

	      application.openFile();
	      application.closeFile();

		
	
	}

}

