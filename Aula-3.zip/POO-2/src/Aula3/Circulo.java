package Aula3;

public class Circulo implements formaGeometrica{

	double raio;
	
	public Circulo(double raio) {
		this.raio = raio;
	}

	@Override
	public double calculePerimetro() {
		return 2*Math.PI*raio;
	}

	@Override
	public double calculeArea() {
		return Math.PI*Math.pow(raio, 2);
	}
	
}
