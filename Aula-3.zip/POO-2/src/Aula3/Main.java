package Aula3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Quantas formas voc� deseja criar?");
		int numFormas = s.nextInt();
		formaGeometrica[] formas = new formaGeometrica[numFormas];
		int j = 0, qCont=0, rCont=0, cCont=0;;
		
		Quadrado[] q = new Quadrado[numFormas];
		Retangulo[] r = new Retangulo[numFormas];
		Circulo[] c = new Circulo[numFormas];
		

		
		for(int i=0; i < numFormas; i++) {
			System.out.println("Voce deseja criar um quadrado (1), retangulo(2) ou um circulo(3)?");
			int opcao = s.nextInt();
			if(opcao == 1) {
				System.out.println("Qual o lado do Quadrado?");
				int lado = s.nextInt();

				q[qCont] = new Quadrado(lado);
				formas[j++] = q[qCont];
				qCont++;

			} else if(opcao == 2) {
				System.out.println("Qual a base do ret�ngulo?");
				int base = s.nextInt();
				System.out.println("Qual a altura do ret�ngulo?");
				int altura = s.nextInt();
				r[rCont] = new Retangulo(base, altura);
				formas[j++] = r[rCont];
				rCont++;
				
			} else {
				System.out.println("Qual o raio do c�rculo?");
				double raio = s.nextDouble();
				c[cCont] = new Circulo(raio);
				formas[j++] = c[cCont];
				cCont++;
			}
		}

		qCont=0;
		rCont=0;
		cCont=0;
		for(int i=0; i < numFormas; i++) {
			if(formas[i] == q[qCont]) {
				System.out.println("O lado do quadrado �: " + q[qCont].lado1);
				System.out.println("O per�metro do quadrado �: " + q[qCont].calculePerimetro());
				System.out.println("A �rea do quadrado �: " + q[qCont].calculeArea());
				qCont++;
			} else if(formas[i] == r[rCont]) {
				System.out.println("O lado do ret�ngulo �: " + r[rCont].lado1);
				System.out.println("O per�metro do ret�ngulo �: " + r[rCont].calculePerimetro());
				System.out.println("A �rea do ret�ngulo �: " + r[rCont].calculeArea());
				rCont++;
			} else if(formas[i] == c[cCont]) {
				System.out.println("O raio do c�rculo �: " + c[cCont].raio);
				System.out.println("O per�metro do c�rculo �: " + c[cCont].calculePerimetro());
				System.out.println("A �rea do c�rculo �: " + c[cCont].calculeArea());
				cCont++;
			}
		}
	}

}
