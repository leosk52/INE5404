package Aula3;

public class Retangulo extends Quadrilateros implements formaGeometrica{

	double base;
	double altura;
	
	public Retangulo(double base, double altura) {
		super(base,	base, altura, altura);
	}	

	@Override
	public double calculeArea() {
		return base*altura;
	}
	
}
