package Aula3;

public interface formaGeometrica {

	public double calculePerimetro();
	public double calculeArea();
	
	
	
}
