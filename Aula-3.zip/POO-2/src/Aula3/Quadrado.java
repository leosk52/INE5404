package Aula3;

public class Quadrado extends Quadrilateros implements formaGeometrica{

	public Quadrado(double a) {
		super(a, a, a, a);
	}

	@Override
	public double calculeArea() {
		return Math.pow(lado1, 2.0);
	}
}
