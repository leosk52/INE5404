package Exercicio2;

import javax.swing.JFrame;

public class Main1 {

	public static void main(String[] args) {

		Teclado teclado = new Teclado();
		/*teclado.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		teclado.setSize(200, 400);
		teclado.setVisible(true);
		*/

	}

}
