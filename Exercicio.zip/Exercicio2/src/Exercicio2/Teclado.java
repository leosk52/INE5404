package Exercicio2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class Teclado extends JFrame implements ActionListener, KeyListener {

	private JLabel labelTec; 
	private JTextArea textArea, textArea1;
	private String letra = "";

	private JButton[] buttons;
	private static final String[] lista = { "~", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "+", "Backspace",
			"Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\",
			"Caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ":", "*", "Enter", "",
			"Shift", "", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "?", "/\\", "", 
			"", "", "", "", "", "", "", "", "", "", "                         ", "<", "\\/", ">"};

	public Teclado() {
		super("Teclado Virtual");

		labelTec = new JLabel("Teclado");
		buttons = new JButton[lista.length];
		JButton[][] matrizBotoes;

		for (int i = 0; i < lista.length; i++) {
			buttons[i] = new JButton(lista[i]);
			buttons[i].setMinimumSize(new Dimension(100, 50));
			buttons[i].setPreferredSize(new Dimension(100, 50));
			buttons[i].setMaximumSize(new Dimension(100, 50));
		}
		// Containers
		JFrame window;
		JPanel jPanelMatrizBotoes;

		matrizBotoes = new JButton[5][14];
		window = new JFrame("Teclado Virtual");
		window.setLayout(new FlowLayout(FlowLayout.LEADING));

		jPanelMatrizBotoes = new JPanel(new GridLayout(matrizBotoes.length, matrizBotoes[0].length, 1, 1));
		jPanelMatrizBotoes.setBorder(new EmptyBorder(1, 1, 1, 1));

		int count = 0;
		int nLinhas = matrizBotoes.length;
		int nColunas = matrizBotoes[0].length;
		for (int i = 0; i < nLinhas; i++) {
			for (int j = 0; j < nColunas; j++) {

				matrizBotoes[i][j] = buttons[count];
				jPanelMatrizBotoes.add(matrizBotoes[i][j]);
				if(count >= 56 && count < 66) {
					buttons[count].setVisible(false);
				}
				count++;
			}
		}

		window.add(jPanelMatrizBotoes);
		window.pack();
		window.setVisible(true);
		//////////////////////////////

		labelTec = new JLabel("Teclado Virtual");
		textArea = new JTextArea(20, 40);
		Box box = Box.createHorizontalBox();
		box.add(new JScrollPane(textArea));
		add(box);
		box.setVisible(true);
		window.add(box);

		window.add(textArea);
		addKeyListener(this);// permite que o frame processe os eventos do teclado

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}

	public void keyPressed(KeyEvent event) {
		for(int i=0; i < lista.length; i++) {
			if(event.getKeyChar() == lista[i].charAt(0) || event.getKeyChar() == lista[i].toLowerCase().charAt(0)) {
				buttons[i].setBackground(Color.GREEN);
			}
		}

		/*letra = KeyEvent.getKeyText(event.getKeyCode());// mostra a tecla
		for(int i=0; i < lista.length; i++) {
			if(letra.equals(lista[i])) {
				buttons[i].setBackground(Color.BLACK);

			}
		}*/
	}

	public void setColor(KeyEvent event) {

	}



	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}


	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

}