package Aula1;

public class Fibonacci {
	public static void main(String[] args) {


		//Fibonacci
		//0 1 1 2 3 5 8 12

		int num1 = 1, num2 = 0;

		System.out.print(num2 + " ");
		System.out.print(num1 + " ");

		for(int i = 0; i < 8; i++){
			num1 = num1 + num2;
			num2 = num1 - num2;
			System.out.print(num1 + " ");
		}
	}


}