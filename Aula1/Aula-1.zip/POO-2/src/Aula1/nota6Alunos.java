package Aula1;

import java.util.Scanner;

public class nota6Alunos {
	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		int aprovados = 0;
		int reprovados = 0;
		int emRec = 0;
		double media = 0;
		double mediaClasse = 0;
		double acum = 0;

		for (int i = 0; i < 6; i++) {
			System.out.println("Digite a primeira nota");
			double nota1 = s.nextDouble();
			System.out.println("Digite a segunda nota");
			double nota2 = s.nextDouble();
			media = (nota1+nota2)/2;
			System.out.println(media);
			if(media >= 6) {
				aprovados++;
			} else if(media >= 3) {
				emRec++;
			} else {
				reprovados++;
			}

			acum += (nota1+nota2);
		}
		
		mediaClasse = acum/12;

		System.out.println(aprovados);
		System.out.println(emRec);
		System.out.println(reprovados);
		System.out.println(mediaClasse);
	}
}
