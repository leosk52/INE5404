package Aula1;

import java.util.Random;

public class Matrizes {

	public static void main(String[] args) {
		
		Random gerador = new Random();
		
		int vetor[] = new int[5];
		int vetor2[] = new int[10];
		int matriz[][] = new int[4][3];
		int maiorElem=0, menorElem=0, calculo = 0;
		int somaPares=0;
		
		for(int i=0; i < vetor.length; i++) {
			vetor[i] = gerador.nextInt(30);
			maiorElem = vetor[i];
			if(vetor[i] > maiorElem) {
				maiorElem = vetor[i];
			}
			System.out.print(vetor[i] + " ");
		}
		
		System.out.println("\n--------------");
		for(int i=0; i < vetor2.length; i++) {
			vetor2[i] = gerador.nextInt(30);
			menorElem = vetor2[i];
			if(vetor2[i] > menorElem) {
				menorElem = vetor2[i];
			}
			System.out.print(vetor2[i] + " ");
		}
		System.out.println("\n--------------");
		for(int i=0; i < matriz.length; i++) {
			for(int j=0; j < matriz[0].length; j++) {
				matriz[i][j] = gerador.nextInt(30);
				System.out.print(matriz[i][j] + " ");
				if (j >= 2) {
					System.out.println();
				}
			}
		}

		calculo = (maiorElem * menorElem);
		
		
		System.out.println("--------------");
		
		for(int i=0; i < matriz.length; i++) {
			for(int j=0; j < matriz[0].length; j++) {
				matriz[i][j] = matriz[i][j] + calculo;
				if(matriz[i][j] % 2 == 0) {
					somaPares+= matriz[i][j];
				}
				System.out.print(matriz[i][j] + " ");
				if (j >= 2) {
					System.out.println();
				}
			}
		}
		
		System.out.println("--------------");
		System.out.print("A soma dos Pares �: " + somaPares);
		
		
		
	}

}
