package Aula1;

import java.util.Scanner;

public class CompanhiaAerea {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		int i = 0, j = 6;
		boolean assentos[] = {	false, false, false, false,
				false, false, false, false,
				false, false};



		for(int x = 0; x < 10; x++) {
			System.out.println("Digite 1 P/ primeira classe e 2 P/ classe econ�mica");
			int a = s.nextInt();
			if(a == 1) {
				assentos[i++] = true;	
				System.out.println("Cart�o de Embarque = " + i + "\n Primeira Classe!");
			} else if(a == 2) {
				if(j >= 10) {
					System.out.println("Classe Econ�mica lotada, "
							+ "Digite 1 P/ ficar na primeira classe ou 2 P/ pr�ximo v�o");
					int b = s.nextInt();
					if(b == 1) {
						assentos[i++] = true;	
						System.out.println("Cart�o de Embarque = " + i + "\n Primeira Classe!");
					} else if (b == 2){
						System.out.println("Pr�ximo v�o parte em 3 horas!");
					}
				} else {
					assentos[j++] = true;
					System.out.println("Cart�o de Embarque = " + j + "\n Classe Econ�mica!");
				}
			}
		}

	}

}
